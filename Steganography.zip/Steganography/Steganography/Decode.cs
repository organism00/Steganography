﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Steganography
{
    public partial class Decode : Form
    {
        public Decode()
        {
            InitializeComponent();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            Dashboard db = new Dashboard();
            db.Show();
            this.Close();
        }

        private void btnUpload_Click(object sender, EventArgs e)
        {
            OpenFileDialog opf = new OpenFileDialog();
            opf.InitialDirectory = @"C:\Users\DESKTOP-QTLKQCS\Desktop\encodeimage";
            opf.Filter = "jpg|*.jpg|png|.*png";
            if (opf.ShowDialog() == DialogResult.OK)
            {
                txtFilePath.Text = opf.FileName.ToString();
                pictureBox1.ImageLocation = txtFilePath.Text;
            }
        }

        private void btnDecode_Click(object sender, EventArgs e)
        {
            Bitmap img = new Bitmap(txtFilePath.Text);
            string Message = "";

            Color ipixel = img.GetPixel(img.Width - 1, img.Height - 1);
            int messlen = ipixel.B;
            for (int i = 0; i < img.Width; i++)
            {
                for ( int j = 0; j < img.Height; j++)
                {
                    Color pixel = img.GetPixel(i, j);
                    if (i < 1 && j < messlen)
                    {
                        Console.WriteLine("-------------------------------------------------");
                        Console.WriteLine("R[" + i + "][" + j + "] :" + pixel.R);
                        Console.WriteLine("G[" + i + "][" + j + "] :" + pixel.G);
                        Console.WriteLine("B[" + i + "][" + j + "] :" + pixel.B);
                        int value = pixel.B;
                        char c = Convert.ToChar(value);
                        string letter = System.Text.Encoding.ASCII.GetString(new byte[] { Convert.ToByte(c) });
                        Message = Message + letter;
                    }
                }
            }
            txtMessage.Text = Message;
        }
    }
}
