﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Steganography
{
    public partial class Dashboard : Form
    {
        public Dashboard()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form1 login = new Form1();
            login.Show();
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Encode en = new Encode();
            en.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Decode de = new Decode();
            de.Show();
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            DialogResult iExit;
            iExit = MessageBox.Show("ARE YOU SURE YO WANT TO EXIT THIS APPLICATION", "message", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if(iExit == DialogResult.Yes)
            {
                Application.Exit();
            }
        }
    }
}
