﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Steganography
{
    public partial class Encode : Form
    {
        public Encode()
        {
            InitializeComponent();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            Dashboard DB = new Dashboard();
            DB.Show();
            this.Close();
        }

        private void btnUpload_Click(object sender, EventArgs e)
        {
            OpenFileDialog opf = new OpenFileDialog();
            opf.InitialDirectory = @"C:\Users\DESKTOP-QTLKQCS\Desktop";
            opf.Filter = "jpg|*.jpg|png|.*png";
            if(opf.ShowDialog() == DialogResult.OK)
            {
                string file = opf.FileName.ToString();
                pictureBox1.ImageLocation = file;
                txtFilePath.Text = file;
            }
        }

        private void btnEncode_Click(object sender, EventArgs e)
        {
            Bitmap img = new Bitmap(txtFilePath.Text);

            for(int i = 0; i < img.Width; i++)
            {
                for( int j = 0; j < img.Height; j++)
                {
                    Color pixel = img.GetPixel(i, j);
                    if(i<1 && j < txtMessage.Text.Length)
                    {
                        Console.WriteLine("R[" + i + "][" + j + "] :" + pixel.R);
                        Console.WriteLine("G[" + i + "][" + j + "] :" + pixel.G);
                        Console.WriteLine("G[" + i + "][" + j + "] :" + pixel.B);
                        char letter = Convert.ToChar(txtMessage.Text.Substring(j,1));
                        int value = Convert.ToInt32(letter);
                        Console.WriteLine("Letter:" + letter + " value:" + value);
                        img.SetPixel(i, j, Color.FromArgb(pixel.R, pixel.G, value));
                    }
                  }
            }
            SaveFileDialog savefile = new SaveFileDialog();
            savefile.Filter = "jpg|*.jpg|png|.*png";
            savefile.InitialDirectory = @"C:\Users\DESKTOP-QTLKQCS\Desktop\encodeimage";
            if (savefile.ShowDialog() == DialogResult.OK)
            {
                txtFilePath.Text = savefile.FileName.ToString();
                pictureBox1.ImageLocation = txtFilePath.Text;
                img.Save(txtFilePath.Text);
            }
        }
    }
}
